import streamlit as st
import google.generativeai as genai
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import re
import os
from datetime import datetime
import json

# Page configuration
st.set_page_config(
    page_title="AI Email Assistant",
    page_icon="✉️",
    layout="wide"
)

# Custom CSS for better UI
st.markdown("""
    <style>
    .stButton > button {
        background-color: #4CAF50;
        color: white;
        border-radius: 5px;
        padding: 0.5rem 1rem;
        border: none;
        cursor: pointer;
        transition: background-color 0.3s;
    }
    .stButton > button:hover {
        background-color: #45a049;
    }
    .chat-message {
        padding: 1rem;
        border-radius: 10px;
        margin-bottom: 1rem;
    }
    .user-message {
        background-color: #e3f2fd;
        text-align: right;
    }
    .assistant-message {
        background-color: #f5f5f5;
    }
    </style>
""", unsafe_allow_html=True)

# Initialize session state
if 'chat_history' not in st.session_state:
    st.session_state.chat_history = []
if 'generated_email' not in st.session_state:
    st.session_state.generated_email = ""
if 'email_sent' not in st.session_state:
    st.session_state.email_sent = False

# Title and description
st.title("🤖 AI Email Assistant")
st.markdown("Generate, translate, and send emails with AI assistance")

# Sidebar for configuration
with st.sidebar:
    st.header("⚙️ Configuration")
    
    # API Key input
    api_key = st.text_input(
        "Gemini API Key",
        type="password",
        placeholder="Enter your Gemini API key",
        help="Get your API key from https://makersuite.google.com/app/apikey"
    )
    
    # Email configuration
    st.subheader("📧 Email Settings (for sending)")
    sender_email = st.text_input(
        "Your Email",
        placeholder="your.email@gmail.com"
    )
    email_password = st.text_input(
        "App Password",
        type="password",
        placeholder="Your app-specific password",
        help="For Gmail, use App Password instead of regular password"
    )
    
    smtp_server = st.selectbox(
        "SMTP Server",
        ["Gmail", "Outlook", "Yahoo", "Custom"],
        help="Select your email provider"
    )
    
    if smtp_server == "Custom":
        smtp_host = st.text_input("SMTP Host", placeholder="smtp.example.com")
        smtp_port = st.number_input("SMTP Port", value=587)
    else:
        smtp_configs = {
            "Gmail": ("smtp.gmail.com", 587),
            "Outlook": ("smtp-mail.outlook.com", 587),
            "Yahoo": ("smtp.mail.yahoo.com", 587)
        }
        smtp_host, smtp_port = smtp_configs.get(smtp_server, ("smtp.gmail.com", 587))
    
    # Save settings button
    if st.button("💾 Save Settings"):
        st.success("Settings saved!")

# Function to initialize Gemini
@st.cache_resource
def init_gemini(api_key):
    try:
        genai.configure(api_key=api_key)
        model = genai.GenerativeModel('gemini-2.0-flash-exp')
        return model
    except Exception as e:
        st.error(f"Failed to initialize Gemini: {str(e)}")
        return None

# Function to extract email from text
def extract_email_from_text(text):
    email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
    emails = re.findall(email_pattern, text)
    return emails

# Function to send email
def send_email(sender, password, recipient, subject, body, smtp_host, smtp_port):
    try:
        # Create message
        msg = MIMEMultipart()
        msg['From'] = sender
        msg['To'] = recipient
        msg['Subject'] = subject
        
        # Add body to email
        msg.attach(MIMEText(body, 'plain'))
        
        # Create SMTP session
        server = smtplib.SMTP(smtp_host, smtp_port)
        server.starttls()  # Enable security
        server.login(sender, password)
        
        # Send email
        text = msg.as_string()
        server.sendmail(sender, recipient, text)
        server.quit()
        
        return True, "Email sent successfully!"
    except Exception as e:
        return False, f"Failed to send email: {str(e)}"

# Function to process user prompt
def process_prompt(model, prompt, context=""):
    try:
        # Check if user wants to send email
        send_email_pattern = r"send.*(?:email|mail).*to\s+([^\s]+@[^\s]+)"
        send_match = re.search(send_email_pattern, prompt.lower())
        
        if send_match and st.session_state.generated_email:
            # User wants to send the email
            recipient = send_match.group(1)
            return "SEND_EMAIL", recipient
        
        # Check if this is an email generation request
        email_keywords = ["email", "mail", "leave", "resignation", "application", "request"]
        is_email_request = any(keyword in prompt.lower() for keyword in email_keywords)
        
        # Prepare the prompt for Gemini
        if context:
            full_prompt = f"""
            Previous context: {context}
            
            New request: {prompt}
            
            Please respond appropriately. If this is a translation request, translate the previous email.
            If this is a modification request, modify the email accordingly.
            If this is a new email request, generate a professional email.
            """
        else:
            if is_email_request:
                full_prompt = f"""
                Generate a professional email based on this request: {prompt}
                
                Format the email with:
                - Subject line (start with "Subject: ")
                - Proper greeting
                - Body content
                - Professional closing
                - Signature placeholder [Your Name]
                
                Make it professional and concise.
                """
            else:
                full_prompt = prompt
        
        # Generate response
        response = model.generate_content(full_prompt)
        return "GENERATED", response.text
        
    except Exception as e:
        return "ERROR", f"Error generating response: {str(e)}"

# Main interface
if api_key:
    model = init_gemini(api_key)
    
    if model:
        # Create two columns
        col1, col2 = st.columns([1, 1])
        
        with col1:
            st.subheader("💬 Chat Interface")
            
            # Chat input
            user_input = st.text_area(
                "Enter your prompt:",
                placeholder="e.g., 'Generate a leave email for 2 days' or 'Translate to Spanish' or 'Send the email to john@example.com'",
                height=100
            )
            
            col_btn1, col_btn2, col_btn3 = st.columns(3)
            with col_btn1:
                if st.button("🚀 Generate/Process", use_container_width=True):
                    if user_input:
                        # Add user message to history
                        st.session_state.chat_history.append({"role": "user", "content": user_input})
                        
                        # Process the prompt
                        status, result = process_prompt(
                            model, 
                            user_input, 
                            st.session_state.generated_email
                        )
                        
                        if status == "SEND_EMAIL":
                            # Try to send email
                            if sender_email and email_password:
                                # Extract subject from generated email
                                subject_match = re.search(r"Subject:\s*(.+)", st.session_state.generated_email)
                                subject = subject_match.group(1) if subject_match else "Email from AI Assistant"
                                
                                # Remove subject line from body
                                body = re.sub(r"Subject:\s*.+\n", "", st.session_state.generated_email)
                                
                                success, message = send_email(
                                    sender_email,
                                    email_password,
                                    result,  # recipient email
                                    subject,
                                    body,
                                    smtp_host,
                                    smtp_port
                                )
                                
                                if success:
                                    st.session_state.chat_history.append({
                                        "role": "assistant", 
                                        "content": f"✅ Email successfully sent to {result}!"
                                    })
                                    st.session_state.email_sent = True
                                else:
                                    st.session_state.chat_history.append({
                                        "role": "assistant", 
                                        "content": f"❌ {message}"
                                    })
                            else:
                                st.session_state.chat_history.append({
                                    "role": "assistant", 
                                    "content": "⚠️ Please configure email settings in the sidebar to send emails."
                                })
                        elif status == "GENERATED":
                            # Store generated content
                            st.session_state.generated_email = result
                            st.session_state.chat_history.append({"role": "assistant", "content": result})
                        else:
                            st.session_state.chat_history.append({"role": "assistant", "content": result})
                        
                        st.rerun()
            
            with col_btn2:
                if st.button("🔄 Clear Chat", use_container_width=True):
                    st.session_state.chat_history = []
                    st.session_state.generated_email = ""
                    st.session_state.email_sent = False
                    st.rerun()
            
            with col_btn3:
                if st.button("📋 Copy Last Email", use_container_width=True):
                    if st.session_state.generated_email:
                        st.toast("Email copied to clipboard! (Note: Use Ctrl+C manually)")
                        st.code(st.session_state.generated_email)
            
            # Display chat history
            st.subheader("📜 Conversation History")
            chat_container = st.container(height=400)
            
            with chat_container:
                for message in st.session_state.chat_history:
                    if message["role"] == "user":
                        st.markdown(f"""
                        <div class="chat-message user-message">
                            <b>You:</b><br>{message["content"]}
                        </div>
                        """, unsafe_allow_html=True)
                    else:
                        st.markdown(f"""
                        <div class="chat-message assistant-message">
                            <b>Assistant:</b><br>{message["content"].replace('\n', '<br>')}
                        </div>
                        """, unsafe_allow_html=True)
        
        with col2:
            st.subheader("📝 Generated Email Preview")
            
            if st.session_state.generated_email:
                # Create a nice preview box
                st.text_area(
                    "Email Content:",
                    value=st.session_state.generated_email,
                    height=400,
                    disabled=False
                )
                
                # Quick action buttons
                col_action1, col_action2 = st.columns(2)
                
                with col_action1:
                    recipient_email = st.text_input(
                        "Recipient Email:",
                        placeholder="recipient@example.com"
                    )
                
                with col_action2:
                    if st.button("📤 Send Email Now", use_container_width=True):
                        if recipient_email and sender_email and email_password:
                            # Extract subject from generated email
                            subject_match = re.search(r"Subject:\s*(.+)", st.session_state.generated_email)
                            subject = subject_match.group(1) if subject_match else "Email from AI Assistant"
                            
                            # Remove subject line from body
                            body = re.sub(r"Subject:\s*.+\n", "", st.session_state.generated_email)
                            
                            success, message = send_email(
                                sender_email,
                                email_password,
                                recipient_email,
                                subject,
                                body,
                                smtp_host,
                                smtp_port
                            )
                            
                            if success:
                                st.success(f"✅ {message}")
                                st.balloons()
                            else:
                                st.error(f"❌ {message}")
                        else:
                            st.warning("Please provide recipient email and configure sender settings.")
            else:
                st.info("Generated emails will appear here. Start by typing a prompt in the chat interface.")
        
        # Example prompts
        with st.expander("💡 Example Prompts"):
            st.markdown("""
            **Email Generation:**
            - "Generate a leave email for 2 days due to fever"
            - "Create a resignation letter with 30 days notice"
            - "Write a job application email for software developer position"
            
            **Translation:**
            - "Translate the email to Spanish"
            - "Convert this to French"
            - "Make it in Hindi"
            
            **Modifications:**
            - "Make it more formal"
            - "Shorten the email"
            - "Add urgency to the request"
            
            **Sending:**
            - "Send the email to manager@company.com"
            - "Send this mail to hr@example.com"
            """)
    else:
        st.error("Failed to initialize Gemini. Please check your API key.")
else:
    st.warning("Please enter your Gemini API key in the sidebar to start using the assistant.")
    st.info("""
    ### 🚀 Getting Started:
    1. Get your Gemini API key from [Google AI Studio](https://makersuite.google.com/app/apikey)
    2. Enter the API key in the sidebar
    3. (Optional) Configure email settings if you want to send emails
    4. Start generating emails with natural language prompts!
    """)

# Footer
st.markdown("---")
st.markdown(
    """
    <div style='text-align: center'>
        <p>Built with ❤️ using Streamlit and Google Gemini</p>
    </div>
    """,
    unsafe_allow_html=True
)
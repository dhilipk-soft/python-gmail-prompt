# AI Email Assistant with Gemini

A powerful Streamlit application that combines email generation, translation, chatbot functionality, and email sending capabilities using Google's Gemini AI.

## Features

### 🎯 Core Features
- **Email Generation**: Create professional emails from simple prompts
- **Translation**: Translate generated emails to any language
- **Chatbot Interface**: Interactive conversation with context retention
- **Email Sending**: Send emails directly from the app via SMTP
- **Smart Context**: Maintains conversation history for better responses

### 💡 Smart Capabilities
- Automatically detects email generation requests
- Recognizes translation commands
- Identifies send email instructions
- Maintains email context for modifications
- Professional formatting with subject lines

## Installation

### Prerequisites
- Python 3.8 or higher
- Gemini API Key (free from Google AI Studio)
- (Optional) Email account with app password for sending

### Step 1: Clone or Download the Project
```bash
# Create a new directory
mkdir email-assistant
cd email-assistant

# Copy the files
# - app.py
# - requirements.txt
# - .env.example
```

### Step 2: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 3: Get Gemini API Key
1. Visit [Google AI Studio](https://makersuite.google.com/app/apikey)
2. Sign in with your Google account
3. Click "Get API Key"
4. Copy the generated key

### Step 4: Configure Email Settings (Optional)
For Gmail users:
1. Go to [Google App Passwords](https://myaccount.google.com/apppasswords)
2. Generate an app-specific password
3. Use this instead of your regular password

## Running the Application

```bash
streamlit run app.py
```

The app will open in your browser at `http://localhost:8501`

## Usage Guide

### 1. Initial Setup
- Enter your Gemini API key in the sidebar
- (Optional) Configure email settings if you want to send emails
- Click "Save Settings"

### 2. Generating Emails

**Example prompts:**
- "Generate a leave email for 2 days due to fever"
- "Create a resignation letter with 30 days notice period"
- "Write a job application for software developer position"
- "Draft an apology email for missing the meeting"

### 3. Translating Emails

After generating an email, you can translate it:
- "Translate to Spanish"
- "Convert this to French"
- "Make it in Hindi"
- "Translate to Japanese"

### 4. Modifying Emails

You can modify the generated email:
- "Make it more formal"
- "Shorten the email"
- "Add more details"
- "Make it urgent"

### 5. Sending Emails

Two ways to send:

**Method 1: Natural Language**
- "Send the email to manager@company.com"
- "Send this mail to hr@example.com"

**Method 2: Manual Send**
- Enter recipient email in the preview section
- Click "Send Email Now"

## Configuration Details

### Email Providers Supported
- **Gmail**: Use app password, not regular password
- **Outlook**: Works with Outlook.com and Office 365
- **Yahoo**: Requires app password
- **Custom**: Configure any SMTP server

### SMTP Settings
| Provider | SMTP Server | Port |
|----------|------------|------|
| Gmail | smtp.gmail.com | 587 |
| Outlook | smtp-mail.outlook.com | 587 |
| Yahoo | smtp.mail.yahoo.com | 587 |

## Features Explained

### Chat History
- Maintains full conversation context
- Allows follow-up questions
- Enables iterative improvements

### Email Preview
- Live preview of generated email
- Editable text area
- Extract subject and body automatically

### Smart Detection
- Automatically identifies email requests
- Recognizes translation commands
- Detects send instructions with email addresses

## Troubleshooting

### Common Issues

1. **"Failed to initialize Gemini"**
   - Check your API key is correct
   - Ensure you have internet connection
   - Verify the API key is active

2. **"Failed to send email"**
   - Use app password, not regular password
   - Check recipient email format
   - Verify SMTP settings
   - Enable "Less secure app access" if needed

3. **Email not generating properly**
   - Be specific in your prompt
   - Include key details (purpose, duration, recipient)
   - Use the example prompts as guides

### Gmail Specific Setup
1. Enable 2-factor authentication
2. Generate app password
3. Use app password in the application
4. Allow access for less secure apps (if needed)

## Security Notes

⚠️ **Important Security Tips:**
- Never share your API keys
- Use app passwords instead of regular passwords
- Don't commit `.env` files to version control
- Keep your credentials secure

## Project Structure

```
email-assistant/
│
├── app.py              # Main Streamlit application
├── requirements.txt    # Python dependencies
├── .env.example       # Example environment variables
└── README.md          # Documentation
```

## Advanced Features

### Context-Aware Responses
The chatbot maintains context, allowing:
- Follow-up questions
- Iterative improvements
- Reference to previous emails

### Multi-Language Support
Supports translation to:
- Spanish, French, German, Italian
- Hindi, Tamil, Telugu, Malayalam
- Chinese, Japanese, Korean
- Arabic, Russian, Portuguese
- And many more!

### Professional Email Formatting
- Automatic subject line generation
- Proper salutation and closing
- Professional tone and structure
- Signature placeholder

## Examples

### Leave Request
**Prompt:** "Generate leave email for tomorrow due to doctor appointment"

**Generated:**
```
Subject: Leave Request - Medical Appointment

Dear [Manager's Name],

I am writing to request a leave of absence for tomorrow, [Date], 
due to a scheduled medical appointment that cannot be rescheduled.

I will ensure all my pending tasks are completed today and will 
coordinate with the team for any urgent matters.

Thank you for your understanding.

Best regards,
[Your Name]
```

### Translation
**Prompt:** "Translate to Spanish"

The email will be professionally translated while maintaining format.

## Support

For issues or questions:
1. Check the troubleshooting section
2. Verify all configurations
3. Ensure latest versions are installed

## License

This project is open source and available for educational purposes.

## Credits

Built with:
- Streamlit - Web interface
- Google Gemini - AI model
- Python - Backend logic

---

**Note:** This application requires active internet connection for AI features.